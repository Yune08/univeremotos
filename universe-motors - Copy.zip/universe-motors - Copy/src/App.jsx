import './App.css'
import Footer from './components/Footer'
import Header from './components/Header'
import Img from './components/Img'
import Parrafo from './components/Parrafo'



function App() {
  return (
    <div className="App">
      <Header/>
      <Img/>
      <Parrafo/>
      <Footer/>
    </div>
  )
}

export default App
