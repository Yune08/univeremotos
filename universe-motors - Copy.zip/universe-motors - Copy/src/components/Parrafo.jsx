const Parrafo =()=>{
    return(
<section className="parrafo">
      <h1>Bienvenido a mi página</h1>

      <p>¡Explora nuestros productos y descubre nuestras promociones!</p>
       <section className="features">
      <div>
        <h2>Productos de alta calidad</h2>
        <p>Contamos con los mejores productos en el mercado, de la más alta calidad.</p>
      </div>
      <div>
        <h2>Atención al cliente</h2>
        <p>Nuestro equipo de atención al cliente está disponible las 24 horas para ayudarte en lo que necesites.</p>
      </div>
    </section>
      <button>Ver más</button>
    </section>
    )
}
export default Parrafo