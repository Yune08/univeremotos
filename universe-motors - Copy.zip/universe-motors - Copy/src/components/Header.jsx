import logo from '../../public/logo1.png'

const Header = () => {
  return (
   <header className="encabezado">
    <nav className="menu-nav">
      <ul>
    <a href="">Inicio</a>
    <a href="">Motos</a>
    <a href="">Contacto</a>
    </ul>
    </nav>
    <section className='logo'>
    <img src={logo} alt="" />
    </section>
   </header>
  )
}

export default Header
