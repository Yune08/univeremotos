import Img from '../components/Img'
import Footer from './Footer'
import Parrafo from './Parrafo'

const Main = () => {
  return (
    <main>
     <section className='galeria'>
        <Img/>
        </section>
        <section className='parrafo'>
        <Parrafo/>
        </section>
        <section className='footer'>
        <Footer/>
        </section>
    </main>
  )
}

export default Main
