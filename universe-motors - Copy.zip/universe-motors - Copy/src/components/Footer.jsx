function Footer (){
    return(
        <footer className="Footer">
            <div>
                <p>Sigueme en mis redes sociales</p>
                <li> <a href="https://www.instagram.com/yuneidisls/">Instagram Asesora de ventas</a></li>
            </div>
        </footer>
    )
}
export default Footer