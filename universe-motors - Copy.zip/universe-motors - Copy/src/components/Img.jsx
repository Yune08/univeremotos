import Bmws1000rr from '../../public/Bmw-s1000rr.jpg'
import Bmwr1200gs from '../../public/Bmw-r-1200-gs.jpg'
import Kawasakininja1000sx from '../../public/Kawasaki-ninja-1000sx.jpg'
import Kawasakininjah2r from '../../public/Kawasaki-ninja-h2r.jpg'
import Kawasakiklx150J from '../../public/Kawasaki-klx-150J.jpg'

function Img(){
    return(
       <section className='galeria'>
        <img src={Bmws1000rr} alt="" />
        <img src={Bmwr1200gs}alt="" />
        <img src={Kawasakininja1000sx} alt="" />
        <img src={Kawasakininjah2r}alt="" />
        <img src={Kawasakiklx150J} alt="" />
       </section>
    )
}
export default Img